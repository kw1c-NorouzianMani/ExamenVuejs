<template>
  <div class="container mt-4">
    <h1>Welkom bij het werk van Maria van Gelder</h1>
    <p>
      Maria van Gelder is een klassieke kunstenares die bekend staat om haar historische en sfeervolle schilderijen.
    </p>
    <img src="@/assets/Maria_logo.png" alt="Logo" class="img-fluid mt-3" style="max-width: 300px;" />
  </div>
</template>

