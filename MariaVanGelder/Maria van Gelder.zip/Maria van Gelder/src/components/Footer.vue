<template>
  <footer class="text-center py-3 mt-4 bg-light">
    <p>&copy; 2025 Maria van Gelder – Alle rechten voorbehouden.</p>
  </footer>
</template>
